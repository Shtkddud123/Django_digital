var data = [
    [1,2],
    [2,1],
    [2,4],
    [1,3],
    [2,2],
    [3,1],
    [3,1],
    [1,1],
    [7,3],
    [8,2],
    [6,4],
    [7,4],
    [8,1],
    [9,2],
    [10,8],
    [9,10],
    [7,8],
    [7,9],
    [8,11],
    [9,9],
];

function printRandomDate() {
    var numLoops = 100;
    var i;
    for (i = 0 ; i < numLoops; i++) {
	console.log(i);
    }
}
